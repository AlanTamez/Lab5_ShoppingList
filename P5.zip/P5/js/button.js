$("#sub").click(function(e){
	let dato = $("#in").val();				//obtiene el valor del input ingresado y lo guarda en la variable dato
	e.preventDefault();						//Evita el refresh
	console.log("ya llegue primera parte");					
	$("#in").val("");						//permite que se borre el valor en el input o mas bien que se sobrescriba nada
	$("#lista").append( `
					<li>
						<div class="data">${dato}</div>
	      				<div class="botones">
		      				<button type="submit" class="checked">
		      					Check
		      				</button>
		      				<button type="submit" class="deleted">
		      					Delete
		      				</button>
		      			</div>
	      			</li> `
	);	//Agrega lo necesario en la lista
});

///Despues de presiionar el boton check revisa si tiene una clase strike o no, y cada click es quiar o poner la clase lo que
///permite que en el CSS detecte o no la clase para que lo subraye
$("#lista").on("click", ".checked", function(b){
	b.preventDefault();
	//console.log("ya llegue second part");
	//this me permite que solo se modifique la clase de la que di click y no todas a la vez
	if($(this).parent().parent().hasClass("strike")){
		//console.log("tiene");
		$(this).parent().parent().removeClass("strike");
	}
	else{
		//console.log("No tiene");
		$(this).parent().parent().addClass("strike");
	}

});

$("#lista").on("click", ".deleted", function(d){
	d.preventDefault();
	//console.log("ya llegue third part");
	$(this).parent().parent().remove();
});

